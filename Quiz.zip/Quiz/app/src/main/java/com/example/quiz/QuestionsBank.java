package com.example.quiz;

import java.util.ArrayList;
import java.util.List;

public class QuestionsBank {

    private static List<QuestionsList> rplQuestions() {

        final List<QuestionsList> questionsLists = new ArrayList<>();

        // Create object of QuestionsList class and pass a questions along with options and answer
        final QuestionsList question1 = new QuestionsList("Untuk keamanan transportasi data ketika upload maupun download diperlukan?", "Gateway", "Router", "Firewall", "Secure socket layer", "Gateway");
        final QuestionsList question2 = new QuestionsList("Untuk menjamin keamanan data pada transaksi online, maka seorang programmer perlu merancang keamanan dengan cara membuat?", "Malicius Code", "Encoder", "Deskripsi", "Enkripsi", "Enkripsi");
        final QuestionsList question3 = new QuestionsList("Untuk mengatasi kesalahan yang mungkin terjadi pada saat program di eksekusi java menyediakan metode yang dinamakan?", "Event handler", "Exception Handling", "Abstrak Windoeing Toolkit", "Multi Threading", "Exception Handling");
        final QuestionsList question4 = new QuestionsList("String yang tidak dapat diubah (konstan) adalah ", "Method", "Immutable", "Math", "Variabel", "Immutable");
        final QuestionsList question5 = new QuestionsList("Segala sesuatu yang menyangkut keamanan dikenal dengan istilah?", "Hardware", "Security", "PC", "Office", "Security");
        final QuestionsList question6 = new QuestionsList("Apa itu Software Engineering?", "Sebuah program komputer dan dokumentasi terkait;", "Disiplin ilmu teknik yang berkaitan dengan semua aspek produksi perangkat lunak dari tahap awal spesifikasi sistem hingga pemeliharaan sistem setelah mulai digunakan", "Semua aspek pengembangan sistem berbasis komputer termasuk perangkat keras, perangkat lunak dan rekayasa proses", "Orang yang memproduksi perangkat lunak", "Disiplin ilmu teknik yang berkaitan dengan semua aspek produksi perangkat lunak dari tahap awal spesifikasi sistem hingga pemeliharaan sistem setelah mulai digunakan");
        final QuestionsList question7 = new QuestionsList("Sistem aplikasi yang berjalan di komputer lokal, seperti PC dan tidak perlu terhubung ke jaringan, merupakan definisi dari tipe aplikasi?", "Entertainment systems", "Interactive transaction-based applications", "Stand-alone applications", "Embedded control systems", "Stand-alone applications");
        final QuestionsList question8 = new QuestionsList("Insinyur perangkat lunak harus bertindak dengan cara yang sesuai dengan kepentingan klien dan pemberi kerja mereka sesuai dengan kepentingan publik, merupakan definisi prinsip etika?", "JUDGMENT", "PRODUCT", "PROFESSION", "CLIENT AND EMPLOYER", "CLIENT AND EMPLOYER");
        final QuestionsList question9 = new QuestionsList("Mengidentifikasi keseluruhan struktur sistem, komponen utama (subsistem atau modul), hubungan mereka dan bagaimana mereka didistribusikan, merupakan tahapan desain?", "Architectural", "Database", "Component selection and design", "Interface", "Architectural");
        final QuestionsList question10 = new QuestionsList("Bagian tahapan pengujian dengan menguji menggunakan data pelanggan untuk memeriksa apakah sistem memenuhi kebutuhan pelanggan, disebut?", "Component testing", "Customer testing", "System testing", "Code testing", "Customer testing");

        // add all questions to List<QuestionsList>
        questionsLists.add(question1);
        questionsLists.add(question2);
        questionsLists.add(question3);
        questionsLists.add(question4);
        questionsLists.add(question5);
        questionsLists.add(question6);
        questionsLists.add(question7);
        questionsLists.add(question8);
        questionsLists.add(question9);
        questionsLists.add(question10);

        return questionsLists;
    }

    private static List<QuestionsList> multimediaQuestions() {

        final List<QuestionsList> questionsLists = new ArrayList<>();

        // Create object of QuestionsList class and pass a questions along with options and answer
        final QuestionsList question1 = new QuestionsList("Shoftware yang digunakan untuk membuat web design adalah :", "Dreamweaver", "Macromedia Flash", "Adobe Audition", "Swish Max", "Dreamweaver ");
        final QuestionsList question2 = new QuestionsList("Shoftware yang digunakan untuk membuat animasi text adalah :", "Adobe Ilustrator", "Swis Max", "Dreamweaver", "Adobe flash", "Swis Max");
        final QuestionsList question3 = new QuestionsList("Yang termasuk program berbasis vektor dalam kategori program modelling adalah :", "3D Studio MAX", "Autocard", "Photoshop", "Macromedia Flash", "3D Studio MAX");
        final QuestionsList question4 = new QuestionsList("Yang terdapat pada standard primitives di 3D MAX adalah :","Box", "Chamfer Box", "Torus Knot", "Chamfer Chli", "Box");
        final QuestionsList question5 = new QuestionsList("Definisi Multimedia adalah :", "Sebuah komputer yang dikonfigurasi sesuai dengan rekomendasi dan memiliki sebuah CD-ROM", "Sistem yang terhubung melalui jaringan yang mempunyai bandwith yang besar", "Bidang pendidikan dalam penyampaian bahan pengajaran secara interaktif dan dapat mempermudah pembelajaran", "Penggunaan beberapa media yang berbeda untuk menggabungkan dan menyampaikan informasi dalam bentuk text, audio, grafik, animasi, dan video", "Penggunaan beberapa media yang berbeda untuk menggabungkan dan menyampaikan informasi dalam bentuk text, audio, grafik, animasi, dan video");
        final QuestionsList question6 = new QuestionsList("Proses pemampatan data audio atau data jenis lainnya yang berukuran besar menjadi jauh lebih kecil disebut :", "Partisi", "Ekstrak", "Kompresi", "Format", "Kompresi");
        final QuestionsList question7 = new QuestionsList("Lembaran-lembaran yang membentuk animasi tunggal dan masing-masing sel merupakan bagian yang terpisah adalah jenis animasi :", "Cell", "Sprite", "Path", "Spline", "Cell");
        final QuestionsList question8 = new QuestionsList("Visual effect dapat dibuat dengan cara motion dynamics yang berarti", "Efek yang disebabkan perubahan posisi terhadap waktu pada suatu obyek", "Efek yang disebabkan perubahan warna pada suatu obyek", "Efek yang disebabkan perubahan bentuk pada suatu obyek", "Efek yang disebabkan oleh perubahan cahaya, posisi, orientasi dan fokus kamera pada suatu obyek", "Efek yang disebabkan perubahan posisi terhadap waktu pada suatu obyek");
        final QuestionsList question9 = new QuestionsList("Definisi dari computer based animation adalah :", "Teknik pengolah video menggunakan komputer dengan tool untuk membuat visual effect", "Teknik pengolahan animas menggunakan komputer dengan tool untuk membuat visual effect", "Teknik pengolahan gambar menggunakan komputer dengan tool untuk membuat visual effect", "Teknik pengolahan visul menggunakan komputer dengan tool untuk membuat visual effect", "Teknik pengolahan animas menggunakan komputer dengan tool untuk membuat visual effect");
        final QuestionsList question10 = new QuestionsList("Pada computer based animation terdapat proses “Sebelum komputer dapat dipakai dalam animasi, gambar harus sisigitalisasi untuk membentuk keyframe terdigitalisasi” adalah definisi :", "Composition Stage", "Input Process", "Editing Animasi", "Inbetween Process", "Input Process");

        // add all questions to List<QuestionsList>
        questionsLists.add(question1);
        questionsLists.add(question2);
        questionsLists.add(question3);
        questionsLists.add(question4);
        questionsLists.add(question5);
        questionsLists.add(question6);
        questionsLists.add(question7);
        questionsLists.add(question8);
        questionsLists.add(question9);
        questionsLists.add(question10);

        return questionsLists;
    }

    private static List<QuestionsList> tkjQuestions() {

        final List<QuestionsList> questionsLists = new ArrayList<>();

        // Create object of QuestionsList class and pass a questions along with options and answer
        final QuestionsList question1 = new QuestionsList("Tujuan dibentuknya workgrup adalah untuk mempermudah", "Mempermudah sharing data", "]Mempermudah pemasangan IP Address", "Mempermudah jaringan internet", "Mempermudah instalasi software", "Mempermudah sharing data");
        final QuestionsList question2 = new QuestionsList("Skema desain pembangunan sebuah jaringan komputer dikenal dengan istilah", "Jaringan tipe", "Topologi", "Desain Jaringan", "Media transmisi", "Topologi");
        final QuestionsList question3 = new QuestionsList("Text perintah yang harus dijalankan untuk melihat apakah kita sudah terhubung ke domain.com adalah dengan menjalankan perintah", "install domain.com", "ls domain.com", "ping domain.com", "rm domain.com", "ping domain.com");
        final QuestionsList question4 = new QuestionsList("Dibawah ini salah satu protokol internet yang sering digunakan untuk transfer data atau file adalah", "DNS", "Sosial Media", "FTP", "HTTP", "FTP");
        final QuestionsList question5 = new QuestionsList("Setiap server membutuhkan spesifiksi computer server yang disesuaikan dengan kebutuhan. Umumnya apabila kita memiliki RAM sebesar 128 MB, maka alokasi minimal yang direkomendasikan untuk partisi linux swap adalah", "128 Mb", "200 Mb", "256 Mb", "100 Mb", "256 Mb");
        final QuestionsList question6 = new QuestionsList("Ping merupakan perintah yang digunakan untuk", "Menguji konektivitas jaringan", "Melihat Mac Address", "Menghapus history Browser", "Mentransfer file antara jaringan", "Menguji konektivitas jaringan");
        final QuestionsList question7 = new QuestionsList("Bagian komputer terbagi menjadi 3 yaitu?", "Software -  Hardware – Output", "Hardware - Software – Brainware", "Harddisk - Monitor – VGA", "Input - Proses – Output", "Hardware - Software – Brainware");
        final QuestionsList question8 = new QuestionsList("Berikut ini contoh hardware adalah?", "VGA", "Mouse", "Flashdisk", "Semua benar", "Semua benar");
        final QuestionsList question9 = new QuestionsList("Dibawah ini yang termasuk distribusi LINUX, kecuali", "Microsoft Windows 10", "Linux Mint", "Debian", "Semua salah", "Microsoft Windows 10");
        final QuestionsList question10 = new QuestionsList("Salah satu perangkat lunak yang bertugas mengatur proses, menterjemahkan masukan, mengatur proses internal, memanajemen memori dan perangkat keras lainnya adalah", "Hardware", "Unix", "BIOS", "Open Office", "BIOS");

        // add all questions to List<QuestionsList>
        questionsLists.add(question1);
        questionsLists.add(question2);
        questionsLists.add(question3);
        questionsLists.add(question4);
        questionsLists.add(question5);
        questionsLists.add(question6);
        questionsLists.add(question7);
        questionsLists.add(question8);
        questionsLists.add(question9);
        questionsLists.add(question10);

        return questionsLists;
    }

    public static List<QuestionsList> getQuestions(String selectedTopicName) {
        switch (selectedTopicName) {
            case "rpl":
                return rplQuestions();
            case "multimedia":
                return multimediaQuestions();
            default:
                return tkjQuestions();
        }
    }
}
